package regression;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.Markup;

import pageObjects.BooksPage;
import pageObjects.CartPage;
import pageObjects.CheckoutdetailsPage;
import pageObjects.DesktopPage;
import pageObjects.HomePage;
import pageObjects.LoginPage;
import testBase.testBase;

public class DemoScenario2 extends testBase {
	
	
	
    @Test(priority = 1)
    public void launchLoginPage() throws Exception {
    	testInfo = reports.createTest("Login test in Demo Web Shop");
        HomePage ob = PageFactory.initElements(driver, HomePage.class);
        ob.clickLogin();
        testInfo.info("Passing all the details");
        LoginPage obj = PageFactory.initElements(driver, LoginPage.class);
        obj.enterEmail();
        obj.enterPassword();
        obj.clickSubmit();
        String screenshotPath = testBase.getScreenhot("Login");
        testInfo.pass("Details",  MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
    }
    
    @Test(priority = 2)
    public void AddingBookToCart() throws Exception {
    	testInfo = reports.createTest("Adding a book in the cart");
    	 HomePage ob = PageFactory.initElements(driver, HomePage.class);
    	 ob.openCategories();
         ob.CategoryBook();
         BooksPage obj = PageFactory.initElements(driver, BooksPage.class);
         obj.clickbook();
         obj.addToCart();
         String screenshotPath = testBase.getScreenhot("Adding book to cart");
         obj.Home();
         testInfo.pass("Details",  MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
    }
    
    @Test(priority = 3)
    public void AddingDesktopToCart() throws Exception {
    	testInfo = reports.createTest("Adding a desktop in the cart");
    	 HomePage ob = PageFactory.initElements(driver, HomePage.class);
    	 ob.openCategories();
         ob.CategoryComputer();
         ob.SubcategoryDesktop();
         DesktopPage obj = PageFactory.initElements(driver, DesktopPage.class);
         obj.clickDestop();
         obj.addToCart();
         String screenshotPath = testBase.getScreenhot("Adding desktop to cart");
         obj.Home();
         testInfo.pass("Details",  MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
    }
    
    @Test(priority = 4)
    public void Cart() throws Exception {
    	testInfo = reports.createTest("Placing the order");
    	HomePage ob = PageFactory.initElements(driver, HomePage.class);
    	ob.clickCart();
    	CartPage obj = PageFactory.initElements(driver, CartPage.class);
    	obj.selectCountry();
    	Thread.sleep(2000);
    	obj.enterZip();
    	obj.checkTerms();
    	obj.clickCheckout();
    	CheckoutdetailsPage obje = PageFactory.initElements(driver, CheckoutdetailsPage.class);
    	obje.selectCountry();
    	Thread.sleep(2000);
    	obje.enterCity();
    	obje.enterAdd();
    	obje.enterZip();
    	obje.enterPhn();
    	obje.clickCheckout();
    	
    	obje.clickContinue1();
    	
    	obje.clickContinue2();
    	
    	obje.clickContinue3();
    	
    	obje.clickContinue3();
    	
    	obje.clickContinue4();
    	
    	obje.clickContinue5();
    	String screenshotPath = testBase.getScreenhot("Order placed");
    	testInfo.pass("Details",  MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
    	
    }
    
    

}
