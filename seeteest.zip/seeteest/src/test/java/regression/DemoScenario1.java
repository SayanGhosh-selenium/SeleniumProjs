package regression;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import pageObjects.HomePage;
import pageObjects.RegisterPage;
import testBase.testBase;

public class DemoScenario1 extends testBase{

	@BeforeTest
	public void setUp() throws FileNotFoundException, IOException {
		testBase.getWebDriver();
	}

	@Test(priority = 1)
	public void launchRegisterPage() throws Exception {
		testInfo = reports.createTest("Registration in Demo Web Shop");
		HomePage ob = PageFactory.initElements(driver, HomePage.class);
		ob.clickRegister();
		testInfo.info("Passing all the details");
		RegisterPage obj = PageFactory.initElements(driver, RegisterPage.class);
		obj.SelectGender();
		obj.enteFirstName();
		obj.enterLastName();
		obj.enterEmail();
		obj.enterPassword();
		obj.enterConfirmPassword();
		obj.clickSubmit();
		String actual = obj.text();
		String expected = "Your registration completed";
		String screenshotPath = testBase.getScreenhot("Registration");
		if(actual.equalsIgnoreCase(expected))
		{
			testInfo.pass("Details",  MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
		}
		else
		{
			Assert.fail();
			testInfo.fail("Details",  MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
		}
	}



}
