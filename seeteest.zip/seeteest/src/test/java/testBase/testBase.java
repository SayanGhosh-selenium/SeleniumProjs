package testBase;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import utility.PropertyFileConnection;


public class testBase {
	
	static Properties properties = PropertyFileConnection.loadconfigFile();
	public static AndroidDriver<AndroidElement> driver;
    static DesiredCapabilities dc = new DesiredCapabilities();
	
    public ExtentReports reports;
    public ExtentTest testInfo;
    public ExtentHtmlReporter htmlReporter;
	

	public static void getWebDriver() throws FileNotFoundException, IOException 
	{	
		String access = properties.getProperty("accessKey");
		try {	

			if (properties.getProperty("Automation").equals("appium")) 
			{
			    dc.setCapability("testName", "Quick Start Android Native Demo");
		        dc.setCapability("accessKey", access );
		        dc.setCapability("deviceQuery", "@os='android' and @category='PHONE'");
		        dc.setCapability("browserName", "Chrome");
				dc.setCapability("noReset", true);
				
				System.setProperty("webdriver.chrome.driver","C:\\Users\\848885\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
				URL url = new URL("https://cloud.seetest.io/wd/hub");
		        driver = new AndroidDriver<>(url, dc);	
		        driver.get(properties.getProperty("URL"));
		        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				

		        /*dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");
		        dc.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");  
		        dc.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		        dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, "10.0");
		        dc.setCapability("browserName", "Chrome");
				dc.setCapability("noReset", true);
			
				System.setProperty("webdriver.chrome.driver","C:\\Users\\848885\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
				URL url = new URL("http://127.0.0.1:4723/wd/hub");
				driver = new AndroidDriver<>(url, dc);	
		        driver.get(properties.getProperty("URL"));
		        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);*/
			} 
			
	}catch(WebDriverException ex) {
		ex.printStackTrace();
		System.out.println(ex.getMessage());
	}
		
	}
	
	@BeforeSuite
	public void setUpSuite()
	{
		htmlReporter = new ExtentHtmlReporter(new File(System.getProperty("user.dir") + "/Reports/SeetestReports.html"));
        reports = new ExtentReports();
        htmlReporter.setAppendExisting(true);
        reports.setSystemInfo("Environment", "Automation");
        reports.attachReporter(htmlReporter);
	}
	
	@AfterSuite
	public void tearDown()
	{
		reports.flush();
	}
	
	public static String getScreenhot(String screenshotName) throws Exception {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
                //after execution, you could see a folder "FailedTestsScreenshots" under src folder
		String destination = System.getProperty("user.dir") + "/Screenshots/"+screenshotName+dateName+".png";
		File finalDestination = new File(destination);
		FileUtils.copyFile(source, finalDestination);
		return destination;
	}
	

}
