package testBase;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.internal.TouchAction;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.ElementOption;

public class PageBase extends testBase {
	
	/***
	 *
	 * @param id
	 * @return
	 */
	public static boolean IsWebElementDisplayedByID(WebElement element)
	{
		if(element.isDisplayed())
		{
			Assert.assertTrue(true);
			return true;
		}else
		{
			Assert.fail("unable to Identify Webelement by Id");
			return false;
		}
	}
	
	/***
	 *
	 * @param xpath
	 * @return
	 */
	public static boolean IsWebElementDisplayedByXpath(WebElement element)
	{
		if(element.isDisplayed())
		{
			Assert.assertTrue(true);
			return true;
		}else
		{
			Assert.fail("unable to Identify Webelement by Xpath");
			return false;
		}
	}
	
	/***
	 *
	 * @param CSS
	 * @return
	 */
	public static boolean IsWebElementDisplayedByCSS(WebElement element)
	{
		if(element.isDisplayed())
		{
			Assert.assertTrue(true);
			return true;
		}else
		{
			Assert.fail("unable to Identify Webelement by CSS");
			return false;
		}
	}
	
	/***
	 *
	 * @param className
	 * @return
	 */
	public static boolean IsWebElementDisplayedByClassName(WebElement element)
	{
		if(element.isDisplayed())
		{
			Assert.assertTrue(true);
			return true;
		}else
		{
			Assert.fail("unable to Identify Webelement by ClassName");
			return false;
		}
	}
	
	/***
	 *
	 * @param css
	 */
	public static void clickCSSWebelement(WebElement element)
	{
		try
		{
			element.click();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	/***
	 *
	 * @param css
	 */
	public static void sentTextByCSSWebelement(WebElement element,String text)
	{
		try
		{
			element.sendKeys(text);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	/***
	 *
	 * @param id
	 */
	public static void clickID(WebElement element)
	{
		try
		{
			element.click();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	/***
	 *
	 * @param id
	 */
	public static void sentTextByID(WebElement element,String text)
	{
		try
		{
			element.sendKeys(text);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	/***
	 *
	 * @param xpath
	 */
	public static void clickXpath(WebElement element)
	{
		try
		{
			element.click();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/***
	 *
	 * @param xpath
	 */
	public static void sentTextByXpath(WebElement element,String text)
	{
		try
		{
			element.sendKeys(text);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	/***
	 *
	 * @param name
	 */
	public static void clickName(WebElement element)
	{
		try
		{
			element.click();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/***
	 *
	 * @param name
	 */
	public static void sentTextByName(WebElement element,String text)
	{
		try
		{
			element.sendKeys(text);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public static void scroll()
	{
		try
		{
			JavascriptExecutor jse = (JavascriptExecutor)driver;
	        jse.executeScript("window.scrollBy(0,750)");
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	public static void navigateBack(int n)
	{
		try
		{
			for(int i =1;i<=n;i++)
			{
				driver.navigate().back();
		        Thread.sleep(2000);
			}
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public static void dropDown(WebElement sel,String country)
	{
		try
		{
			

			List<AndroidElement> allOptions = driver.findElements(By.xpath("//select[@id='CountryId']//option")); //get all the options from the dropdown

			for(WebElement option : allOptions) { 
				System.out.println(option.getText());
				if (option.getText().equals("Canada")) 
				{
				option.click();
				break;
				}

				}
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public static void dropDown1(WebElement sel,String country)
	{
		try
		{
			

			List<AndroidElement> allOptions = driver.findElements(By.xpath("//select[@id='BillingNewAddress_CountryId']//option")); //get all the options from the dropdown

			for(WebElement option : allOptions) { 
				System.out.println(option.getText());
				if (option.getText().equals("Canada")) 
				{
				option.click();
				break;
				}

				}
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public static void tapAction(WebElement element)
	{
		try
		{
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].click();", element);
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	

}
