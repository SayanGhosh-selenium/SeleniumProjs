package runner;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;


public class TestNGrunner {



	public static void main(String args[])
	{
		TestNG obj = new TestNG();

		//Define a list of string
		List<String> suites = new ArrayList<String>();

		//Adding TestNG xml files
		suites.add("C:\\Users\\848885\\eclipse-workspace\\seeteest\\testngRun1.xml");
		suites.add("C:\\Users\\848885\\eclipse-workspace\\seeteest\\testngRun2.xml");


		obj.setTestSuites(suites);
		obj.run();
	}

	


}
