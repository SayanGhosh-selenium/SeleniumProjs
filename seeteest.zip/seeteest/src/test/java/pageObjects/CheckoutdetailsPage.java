package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import testBase.PageBase;
import utility.DataSheetConnection;

public class CheckoutdetailsPage {
	
	@FindBy(xpath = "//input[@id='BillingNewAddress_FirstName")
	public static WebElement firstName;
	
	@FindBy(xpath = "//input[@id='BillingNewAddress_LastName']")
	public static WebElement lastName;
	
	@FindBy(xpath = "//input[@id='BillingNewAddress_Email']")
	public static WebElement Email;
	
	@FindBy(xpath = "//select[@id='BillingNewAddress_CountryId']")
	public static WebElement Country;
	
	@FindBy(xpath = "//input[@id='BillingNewAddress_City']")
	public static WebElement City;
	
	@FindBy(xpath = "//input[@id='BillingNewAddress_Address1']")
	public static WebElement Address;
	
	@FindBy(xpath = "//input[@id='BillingNewAddress_ZipPostalCode']")
	public static WebElement Zip;
	
	@FindBy(xpath = "//input[@id='BillingNewAddress_PhoneNumber']")
	public static WebElement Phone;
	
	@FindBy(xpath = "//*[@value='Continue']")
	public static WebElement nextpage;
	
	@FindBy(xpath = "//*[@value='Continue' and @onclick='Shipping.save()']")
	public static WebElement continue1;
	
	@FindBy(xpath = "//*[@value='Continue' and @onclick='ShippingMethod.save()']")
	public static WebElement continue2;
	
	@FindBy(xpath = "//*[@value='Continue' and @onclick='PaymentMethod.save()']")
	public static WebElement continue3;
	
	@FindBy(xpath = "//*[@value='Continue' and @onclick='PaymentInfo.save()']")
	public static WebElement continue4;
	
	@FindBy(xpath = "//*[@value='Confirm']")
	public static WebElement continue5;
	
	public void enteFirstName()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(firstName))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String fname=ob.read(1, 0);
				PageBase.sentTextByXpath(firstName, fname);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void enterLastName()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(lastName))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String lname=ob.read(1, 1);
				PageBase.sentTextByXpath(lastName, lname);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void enterEmail()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(Email))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String email=ob.read(1, 2);
				PageBase.sentTextByXpath(Email, email);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void selectCountry()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(Country))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String country=ob.read(1, 5);
				PageBase.dropDown1(Country,country );
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void enterCity()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(City))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String town=ob.read(1, 6);
				PageBase.sentTextByXpath(City, town);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void enterAdd()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(Address))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String add=ob.read(1, 7);
				PageBase.sentTextByXpath(Address, add);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void enterZip()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(Zip))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String code=ob.read(1, 5);
				PageBase.sentTextByXpath(Zip, code);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void enterPhn()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(Phone))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String no=ob.read(1, 8);
				PageBase.sentTextByXpath(Phone, no);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void clickCheckout()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(nextpage))
			{
				
				PageBase.tapAction(nextpage);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void clickContinue1()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(continue1))
			{
				
			PageBase.clickXpath(continue1);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void clickContinue2()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(continue2))
			{
				
				PageBase.clickXpath(continue2);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void clickContinue3()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(continue3))
			{
				
				PageBase.clickXpath(continue3);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void clickContinue4()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(continue4))
			{
				PageBase.clickXpath(continue4);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void clickContinue5()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(continue5))
			{
				PageBase.clickXpath(continue5);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}


}
