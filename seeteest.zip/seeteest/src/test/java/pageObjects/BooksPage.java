package pageObjects;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import testBase.PageBase;

public class BooksPage {
	
	@FindBy(xpath = "//*[@text='Computing and Internet' and @nodeName='A']")
	public static WebElement book1;
	
	@FindBy(xpath = "//input[@id='add-to-cart-button-13']")
	public static WebElement bookCart;
	
	public void clickbook()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(book1))
			{
			PageBase.clickXpath(book1);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void addToCart()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(bookCart))
			{
			PageBase.scroll();
			PageBase.clickXpath(bookCart);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void Home()
	{
		try
		{
			PageBase.navigateBack(2);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
