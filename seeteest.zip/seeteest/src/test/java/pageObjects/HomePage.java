package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import testBase.PageBase;

public class HomePage extends PageBase {
	
	@FindBy(xpath = "//a[contains(text(),'Register')]")
	public static WebElement register;

	@FindBy(xpath = "//a[contains(text(),'Log out')]")
	public static WebElement logout;

	@FindBy(xpath = "//a[contains(text(),'Log in')]")
	public static WebElement login;

	@FindBy(xpath = "//*[@nodeName='SPAN' and ./*[@nodeName='SPAN']]")
	public static WebElement categories;

	@FindBy(xpath = "//*[@text='Books        ']")
	public static WebElement books;

	@FindBy(xpath = "//*[@text='Computers        ']")
	public static WebElement computers;

	@FindBy(xpath = "//*[@text='                                    Desktops']")
	public static WebElement desktops;

	@FindBy(xpath = "//*[@text='Shopping cart' and @nodeName='SPAN']")
	public static WebElement cart;

	public void clickRegister()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(register))
			{
				PageBase.clickXpath(register);
			}
			else {
				Assert.fail();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void clickLogin()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(logout))
			{
				PageBase.clickXpath(logout);
				PageBase.clickXpath(login);
			}
			else {
				Assert.fail();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void openCategories()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(categories))
			{
				PageBase.clickXpath(categories);
			}
			else {
				Assert.fail();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void CategoryBook()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(books))
			{
				PageBase.clickXpath(books);
			}
			else {
				Assert.fail();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void CategoryComputer()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(computers))
			{
				PageBase.clickXpath(computers);
			}
			else {
				Assert.fail();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void SubcategoryDesktop()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(desktops))
			{
				PageBase.clickXpath(desktops);
			}
			else {
				Assert.fail();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void clickCart()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(cart))
			{
				PageBase.clickXpath(cart);
			}
			else {
				Assert.fail();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
