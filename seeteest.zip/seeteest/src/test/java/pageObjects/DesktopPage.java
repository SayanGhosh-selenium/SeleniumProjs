package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import testBase.PageBase;

public class DesktopPage {
	
	@FindBy(xpath = "//*[@text='Build your own cheap computer' and @nodeName='A']")
	public static WebElement comp;
	
	@FindBy(css = "#add-to-cart-button-72")
	public static WebElement compCart;
	
	public void clickDestop()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(comp))
			{
			PageBase.clickXpath(comp);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void addToCart()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(compCart))
			{
			PageBase.scroll();
			PageBase.clickCSSWebelement(compCart);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void Home()
	{
		try
		{
			PageBase.navigateBack(2);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
