package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import testBase.PageBase;
import utility.DataSheetConnection;

public class CartPage {
	
	@FindBy(xpath = "//select[@id='CountryId']")
	public static WebElement country;
	
	@FindBy(xpath = "//input[@id='ZipPostalCode']")
	public static WebElement zipCode;
	
	@FindBy(xpath = "//input[@id='termsofservice']")
	public static WebElement terms;
	
	@FindBy(xpath = "//button[@id='checkout']")
	public static WebElement checkoutButtn;
	
	
	public void selectCountry()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(country))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String Country=ob.read(1, 5);
				PageBase.dropDown(country,Country );
				
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void enterZip()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(zipCode))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String code=ob.read(1, 5);
				PageBase.sentTextByXpath(zipCode, code);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void checkTerms()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(terms))
			{
			PageBase.clickXpath(terms);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void clickCheckout()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(checkoutButtn))
			{
			PageBase.clickXpath(checkoutButtn);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
