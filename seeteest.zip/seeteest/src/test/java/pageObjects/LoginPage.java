package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import testBase.PageBase;
import testBase.testBase;
import utility.DataSheetConnection;

public class LoginPage extends testBase{
	
	@FindBy(xpath = "//input[@id='Email']")
	public static WebElement Email;
	
	@FindBy(xpath = "//input[@id='Password']")
	public static WebElement Password;
	
	@FindBy(xpath = "//*[@value='Log in']")
	public static WebElement signin;
	
	
	public void enterEmail()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(Email))
			{
			DataSheetConnection ob = new DataSheetConnection();
			String email=ob.read(1, 2);
			WebDriverWait wait = new WebDriverWait(driver,30);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='Email']")));
			PageBase.sentTextByXpath(Email, email);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void enterPassword()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(Password))
			{
			DataSheetConnection ob = new DataSheetConnection();
			String password=ob.read(1, 3);
			PageBase.sentTextByXpath(Password, password);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void clickSubmit()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(signin))
			{
			PageBase.clickXpath(signin);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
