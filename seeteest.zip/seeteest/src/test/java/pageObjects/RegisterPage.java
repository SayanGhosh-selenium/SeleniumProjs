package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import testBase.PageBase;
import utility.DataSheetConnection;

public class RegisterPage {

	@FindBy(xpath = "//label[contains(text(),'Male')]")
	public static WebElement GenderM;

	@FindBy(xpath = "//*[@name='FirstName']")
	public static WebElement firstName;

	@FindBy(xpath = "//input[@id='LastName']")
	public static WebElement lastName;

	@FindBy(xpath = "//input[@id='Email']")
	public static WebElement Email;

	@FindBy(xpath = "//input[@id='Password']")
	public static WebElement Password;

	@FindBy(xpath = "//input[@id='ConfirmPassword']")
	public static WebElement ConfirmPassword;

	@FindBy(xpath = "//input[@id='register-button']")
	public static WebElement registerbuttn;

	@FindBy(xpath = "//div[contains(text(),'Your registration completed')]")
	public static WebElement confirmText;

	@FindBy(xpath = "//body/div[4]/div[1]/div[4]/div[2]/div[1]/div[2]/div[2]/input[1]")
	public static WebElement contbuttn;

	public void SelectGender()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(GenderM))
			{
				PageBase.clickXpath(GenderM);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void enteFirstName()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(firstName))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String fname=ob.read(1, 0);
				PageBase.sentTextByXpath(firstName, fname);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void enterLastName()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(lastName))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String lname=ob.read(1, 1);
				PageBase.sentTextByXpath(lastName, lname);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void enterEmail()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(Email))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String email=ob.read(1, 2);
				PageBase.sentTextByXpath(Email, email);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void enterPassword()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(Password))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String password=ob.read(1, 3);
				PageBase.sentTextByXpath(Password, password);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void enterConfirmPassword()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(ConfirmPassword))
			{
				DataSheetConnection ob = new DataSheetConnection();
				String password=ob.read(1, 3);
				PageBase.sentTextByXpath(ConfirmPassword, password);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void clickSubmit()
	{
		try
		{
			if(PageBase.IsWebElementDisplayedByXpath(registerbuttn))
			{
				PageBase.clickXpath(registerbuttn);
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public String text()
	{
		String text = "";
		try
		{
			text = confirmText.getText();
			System.out.println(text);
			//PageBase.clickXpath(contbuttn);

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return text;
	}


}
