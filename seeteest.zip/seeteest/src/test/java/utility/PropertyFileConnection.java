package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import testBase.PageBase;

public class PropertyFileConnection {
	
	

	

	protected static String configPackagePath = "src\\main\\java\\InputFiles";;
	protected static String Inputdetails = "configfile.properties";
	
	static Properties properties = loadconfigFile();

	public static Properties getInstance() {
		return properties;
	}

	public static Properties loadconfigFile() {
		Properties properties = new Properties();
		try {

			properties.load(new FileInputStream(System.getProperty("user.dir") + File.separator + configPackagePath
					+ File.separator + Inputdetails));
			
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
		return properties;
	}

}
