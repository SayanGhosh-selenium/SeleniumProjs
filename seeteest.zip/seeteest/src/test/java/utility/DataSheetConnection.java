package utility;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataSheetConnection {
	
	public String read(int r , int c) throws Exception
	{
		File src = new File(System.getProperty("user.dir")+  File.separator +"src\\main\\java\\InputFiles\\TestDatasheet.xlsx");
		FileInputStream fis = new FileInputStream(src);
		XSSFWorkbook wb = new XSSFWorkbook(fis); 
		XSSFSheet sh1 = wb.getSheetAt(0);
		
		String s = sh1.getRow(r).getCell(c).getStringCellValue();
		
		return s;
		
	}

}
