package com.sampleproject.runner;

import cucumber.api.CucumberOptions;
import java.io.File;

import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.vimalselvam.cucumber.listener.ExtentProperties;
import com.vimalselvam.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

public class TestngRunner 
{
	 @CucumberOptions(features = "src\\test\\resources\\features", //path of feature files
				format = {"pretty","html:target/cucumber"},
				glue = { "com.sampleproject.stepdefinitions" }, //path of stepdefinitions file
				tags = { "@CustomerAddress"}, //tags for running specific feature files
				monochrome = true, 
				plugin= {"com.vimalselvam.cucumber.listener.ExtentCucumberFormatter:"})
	 
	 public class TestngTestRunnerTest extends AbstractTestNGCucumberTests 
		{
     	@BeforeClass
		    public void setup(){
		        ExtentProperties extentProperties = ExtentProperties.INSTANCE;
		        extentProperties.setReportPath("testReports/redbus_Report.html");
		        extentProperties.getProjectName();    
		    }

		    @AfterClass
		    public void postRun() throws Exception{
		        Reporter.loadXMLConfig(new File("src/test/resources/extentConfig.xml"));
		        Reporter.setSystemInfo("User Id", System.getProperty("user.name"));
		        Reporter.setSystemInfo("Operating System", "Windows 10");
		        Reporter.setSystemInfo("Browser Name", " ");
		        Reporter.setSystemInfo("Application Name", "");
		        Reporter.setSystemInfo("Regression Tests Executed Enviroment", "AT Enviroment");
		        Reporter.setSystemInfo("Regression Tests Executed Enviroment Url", " ");			        
		        Reporter.setTestRunnerOutput("Run Regression Tests");

		    }
		}	 
}
