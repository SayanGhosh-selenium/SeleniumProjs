package com.sampleproject.runner;
import java.io.File;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.vimalselvam.cucumber.listener.ExtentProperties;
import com.vimalselvam.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)

@CucumberOptions(features = "src\\test\\resources\\features\\", 
glue = {"com.sampleproject.stepdefinitions"}, 
tags = {"@emailbus"},
monochrome = true, 
format = {"pretty","html:target/cucumber"},
plugin = {"com.vimalselvam.cucumber.listener.ExtentCucumberFormatter:" })


public class JunitRunner 
{

		  @BeforeClass
		    public static void setup(){
		        ExtentProperties extentProperties = ExtentProperties.INSTANCE;
		        extentProperties.setReportPath("testReports/RedBus_Report.html");
		        extentProperties.getProjectName();    
		    }
		    
		    @AfterClass
		    public static void postRun() throws Exception{
		        Reporter.loadXMLConfig(System.getProperty("user.dir")+File.separator+"src/test/resources/extentConfig.xml");
		        Reporter.setSystemInfo("User Id", System.getProperty("user.name"));
		        Reporter.setSystemInfo("Operating System", "Windows 10");
		        Reporter.setSystemInfo("Browser Name", "");
		        Reporter.setSystemInfo("Application Name", " ");
		        Reporter.setSystemInfo("Regression Tests Executed Enviroment", " ");
		        Reporter.setSystemInfo("Regression Tests Executed Enviroment Url", " ");			        
		        Reporter.setTestRunnerOutput("Run Regression Tests");

		    }
}
