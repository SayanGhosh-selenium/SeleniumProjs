package com.sampleproject.stepdefinitions;

import com.sampleproject.pages.Homepage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HomeStepdefinition {
	
	@Given("^: User should have valid Redbus\\.in url$")
	public void user_should_have_valid_Redbus_in_url() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^: User should launch Redbus\\.in$")
	public void user_should_launch_Redbus_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^: User should be in Redbus\\.in$")
	public void user_should_be_in_Redbus_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Given("^: User is in redbus\\.in$")
	public void user_is_in_redbus_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}
	
	@When("^: User should click on manage booking dropdown$")
	public void user_should_click_on_manage_booking_dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Homepage.manageMyBooking();
	}
	
	@And("^: User should select show my ticket from dropdown$")
	public void user_should_select_show_my_ticket_from_dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Homepage.showticketClick();
	}
	
	@And("^: User should select Email/SMS from dropdown$")
	public void user_should_select_Email_SMS_from_dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Homepage.EmailClick();
	}

}
