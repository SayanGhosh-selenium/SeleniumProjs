package com.sampleproject.stepdefinitions;

import com.sampleproject.pages.SendSMSpage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class emailStepdefinition {
	
	@Then("^: User should navigate to verify my ticket page$")
	public void user_should_navigate_to_verify_my_ticket_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Given("^: User should be in verify my ticket page$")
	public void user_should_be_in_verify_my_ticket_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^: User should enter ticket number in text box$")
	public void user_should_enter_ticket_number_in_text_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    SendSMSpage.ticketno();
	    
	}

	@And("^: User should enter email_id in the text box$")
	public void user_should_enter_email_id_in_the_text_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		SendSMSpage.email();
	}

	@And("^: User should click on Proceed button$")
	public void user_should_click_on_Proceed_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		SendSMSpage.clickSubmit();
	}

}
