package com.sampleproject.stepdefinitions;

import com.sampleproject.pages.PrintTicketpage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class printStepdefinition {

	@Then("^: User should navigate to print my ticket page$")
	public void user_should_navigate_to_print_my_ticket_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Given("^: User should be in print my ticket page$")
	public void user_should_be_in_print_my_ticket_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions	    
	}

	@When("^: User should enter Ticket number in text box$")
	public void user_should_enter_Ticket_number_in_text_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   PrintTicketpage.enterTicketno();
	}

	@And("^: User should enter email id in the text box$")
	public void user_should_enter_email_id_in_the_text_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PrintTicketpage.email();
	}

	@And("^: User should click on submit button$")
	public void user_should_click_on_submit_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PrintTicketpage.clickSubmit();
	}

	@Then("^: User should verify error message$")
	public void user_should_verify_error_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

}
