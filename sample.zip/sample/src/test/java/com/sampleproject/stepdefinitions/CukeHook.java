package com.sampleproject.stepdefinitions;

import com.sampleproject.utility.BrowserType;
import com.sampleproject.utility.PageWebelements;
import cucumber.api.Scenario;
import cucumber.api.java.Before;

public class CukeHook extends PageWebelements
{
	
com.sampleproject.utility.InvokeApplication invokeApplication = new com.sampleproject.utility.InvokeApplication();
	
	@Before
	public void Testinitialize(Scenario scenario) 
	{
		try {
	
		    currentScenario = scenario;
			Thread.sleep(2000);
			System.out.println("Running the Scenario : " + scenario.getName());
            driver = BrowserType.getWebDriver();
            invokeApplication.LaunchRADRApplication(driver);          
            
		} catch (Exception e)
		{
			e.printStackTrace();
			
		}
	}
}
