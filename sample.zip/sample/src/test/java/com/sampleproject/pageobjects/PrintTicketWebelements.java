package com.sampleproject.pageobjects;

public class PrintTicketWebelements {
	
	//ID
	public static String ticketno = "searchTicketTIN" ;
	
	//ID
	public static String emailid = "searchTicketEmail" ;
	
	//ID
	public static String submitbuttn = "ticketSearch" ;

}
