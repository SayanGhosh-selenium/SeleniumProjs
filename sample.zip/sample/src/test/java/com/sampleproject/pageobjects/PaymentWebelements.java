package com.sampleproject.pageobjects;

public class PaymentWebelements {

	//Xpath
	public static String name = "/html[1]/body[1]/section[1]/div[2]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/label[1]/input[1]" ;

	//Xpath
	public static String genderM = "/html[1]/body[1]/section[1]/div[2]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/span[1]/div[1]/div[1]" ;

	//Xpath
	public static String genderF = "/html[1]/body[1]/section[1]/div[2]/div[1]/div[1]/div[5]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/span[2]/div[1]/div[1]" ;

	//Xpath
	public static String age = "/html[1]/body[1]/section[1]/div[2]/div[1]/div[1]/div[5]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/label[1]/input[1]" ;

	//Xpath
	public static String email = "/html[1]/body[1]/section[1]/div[2]/div[1]/div[1]/div[5]/div[3]/div[1]/div[2]/div[1]/div[2]/div[2]/div[1]/label[1]/input[1]" ;

	//Xpath
	public static String phn = "/html[1]/body[1]/section[1]/div[2]/div[1]/div[1]/div[5]/div[3]/div[1]/div[2]/div[1]/div[2]/div[3]/div[1]/div[2]/div[1]/label[1]/input[1]" ;

	//Xpath
	public static String submitbuttn = "/html[1]/body[1]/section[1]/div[2]/div[1]/div[1]/div[5]/div[3]/div[2]/div[2]/input[1]" ;


}
