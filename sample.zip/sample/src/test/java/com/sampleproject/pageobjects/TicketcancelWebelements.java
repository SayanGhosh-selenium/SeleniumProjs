package com.sampleproject.pageobjects;

public class TicketcancelWebelements {

	//Name
	public static String ticketno = "tin" ;

	//Name
	public static String emailid = "email" ;

	//Xpath
	public static String submitbuttn = "//div[contains(text(),'Select Passengers')]" ;

}
