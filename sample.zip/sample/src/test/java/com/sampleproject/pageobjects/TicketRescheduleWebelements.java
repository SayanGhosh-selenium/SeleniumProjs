package com.sampleproject.pageobjects;

public class TicketRescheduleWebelements {

	//ID
	public static String ticketno = "searchTicket" ;

	//ID
	public static String emailid = "searchEmail" ;

	//Xpath
	public static String submitbuttn = "/html[1]/body[1]/section[1]/div[2]/div[2]/div[2]/div[3]/input[1]" ;


}
