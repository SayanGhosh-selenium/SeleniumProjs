package com.sampleproject.pageobjects;

public class PilligrimageWebelements {

	//Xpath
	public static String page = "//a[contains(text(),'PILGRIMAGE')]" ;


	//Xpath
	public static String tirupathi = "/html[1]/body[1]/div[2]/div[1]/div[1]/div[1]/section[3]/div[1]/ul[1]/li[2]/div[1]/div[1]/ul[1]/li[1]/span[1]" ;


}
