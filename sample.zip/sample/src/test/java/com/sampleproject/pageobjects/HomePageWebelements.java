package com.sampleproject.pageobjects;

public class HomePageWebelements {
	
	//ID for source place
	public static final String source = "src" ;
	
	//ID for destination place
	public static final String destination = "dest" ;
	
	//Xpath for date 
	public static final String date = ".//input[@id='onward_cal']" ;
	
	//ID for search button
	public static final String search_buttn = "search_btn" ;
	
	//xpath for manage booking
	public static final String manage_booking = "//div[contains(text(),'Manage Booking')]" ;
	
	//xpath for cancel
	public static final String cancel = "//span[contains(text(),'Cancel')]" ;
	
	//xpath for reschedule
	public static final String reschedule = "//span[contains(text(),'Reschedule')]" ;
	
	//xpath for print
    public static final String print = "//span[contains(text(),'Show My Ticket')]" ;
    
    //xpath for ticket verification
    public static final String ticket_verf = "//span[contains(text(),'Show My Ticket')]" ;
    
    //ID for rpool page
  	public static final String rpool = "cars" ;
  	
  	//ID for rbus hire 
  	public static final String rbus_hire = "redBus Bus Hire" ;
  	
  	//Xpath
    public static final String datelist="//td[@class='wd day' or @class='we day' ]";

}
