package com.sampleproject.pageobjects;

public class SendSMSWebelements {

	//ID
	public static String ticketno = "searchTicketTIN" ;

	//
	public static String emailid = "searchTicketEmail" ;

	//ID
	public static String submitbuttn = "ticketSearch" ;


}
