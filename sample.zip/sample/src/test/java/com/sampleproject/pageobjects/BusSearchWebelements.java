package com.sampleproject.pageobjects;

public class BusSearchWebelements {

	//Xpath
	public static String viewbus = "//div[contains(text(),'Select Passengers')]" ;

	//Xpath
	public static String viewseat = "/html[1]/body[1]/section[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[3]/ul[1]/div[1]/li[1]/div[1]/div[2]/div[1]" ;

	//Css
	public static String seatbook = "div.search div.srp-data.clearfix div.sort-results.w-80.fl div.result-sec ul.bus-items li.row-sec.clearfix.fix.active.scrollActive:nth-child(1) div.seat-container-wrapper div.seat-container-div.seatlayout-main-body.clearfix div.seat-container div.SeatsSelectorWrapper div.clearfix.SeatsSelector.MB div.leftContent.clearfix.m-top-10.seatlayout-padding-40 div.seat-layout.clearfix div.lower-canvas.canvas-wrapper > canvas:nth-child(2)" ;

	//Xpath
	public static String Boardingpoint = "/html[1]/body[1]/section[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[3]/ul[1]/div[1]/li[1]/div[2]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/ul[1]/li[1]/div[1]/div[1]" ;

	//Xpath
	public static String droppingpoint = "/html[1]/body[1]/section[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[3]/ul[1]/div[1]/li[1]/div[2]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/ul[1]/li[1]/div[1]/div[1]" ;

	//Xpath
	public static String continuebuttn = "/html[1]/body[1]/section[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[3]/div[1]/ul[1]/div[1]/li[1]/div[2]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/button[1]" ;
	
	//Xpath
	public static String proceedbuttn = "/html[1]/body[1]/section[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[3]/div[1]/ul[1]/div[1]/li[1]/div[2]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[6]/button[1]" ;
	

}
