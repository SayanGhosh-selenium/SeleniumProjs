package com.sampleproject.utility;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import com.vimalselvam.cucumber.listener.Reporter;


public class InvokeApplication extends PageWebelements
{
	/***
	 * 
	 * @param driver
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	
	static Properties properties = PropertyFileConnection.loadconfigFile();
	
	public static void LaunchRADRApplication (WebDriver driver) throws FileNotFoundException, IOException
	{		
		if(driver!=null) 			
		{				
			driver.manage().deleteAllCookies();				
			driver.get(properties.getProperty("Url"));	
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); 			
		}else 
		{			
			Assert.fail();
			Reporter.addStepLog("Application is ...loading");
		}			
	}
	
}
