package com.sampleproject.utility;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;


public class BrowserType extends PageWebelements
{
    
	static Properties properties = PropertyFileConnection.loadconfigFile();
	
	public static WebDriver getWebDriver() throws FileNotFoundException, IOException 
	{	try {	

			if (properties.getProperty("Browsertype").equals("Chrome")) 
			{
				System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"\\Browsers\\chromedriver.exe");		
				ChromeOptions chromeOptions = new org.openqa.selenium.chrome.ChromeOptions();
				chromeOptions.addArguments("--disable-notifications");
				driver = new org.openqa.selenium.chrome.ChromeDriver(chromeOptions);
							
			} 
			else if (properties.getProperty("Browsertype").equals("FireFox")) {
				driver = new FirefoxDriver();
			} 
			else if (properties.getProperty("Browsertype").equals("IE"))
			{

				driver = new InternetExplorerDriver();
				

			}
			
	}catch(WebDriverException ex) {
		ex.printStackTrace();
		System.out.println(ex.getMessage());
	}
		return driver;
	}
	
	
	
	
	
}
