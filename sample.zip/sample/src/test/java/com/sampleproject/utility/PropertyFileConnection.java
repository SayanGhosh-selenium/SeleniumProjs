package com.sampleproject.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertyFileConnection extends PageWebelements 
{
	protected static String configPackagePath = "src\\main\\java\\com\\InputFiles";;
	protected static String Inputdetails = "configfile.properties";
	
	static Properties properties = loadconfigFile();

	public static Properties getInstance() {
		return properties;
	}

	public static Properties loadconfigFile() {
		Properties properties = new Properties();
		try {

			properties.load(new FileInputStream(System.getProperty("user.dir") + File.separator + configPackagePath
					+ File.separator + Inputdetails));
			
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
		return properties;
	}
}
