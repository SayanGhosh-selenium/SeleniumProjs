package com.sampleproject.utility;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot extends PageWebelements{
	
	public static byte[] takeScreenshot(WebDriver driver) {
        if (driver == null) {
            throw new RuntimeException("Report.driver is not initialized!");
        }

 

        if (driver.getClass().getSimpleName().equals("HtmlUnitDriver")
                || driver
                        .getClass()
                        .getGenericSuperclass()
                        .toString()
                        .equals("class org.openqa.selenium.htmlunit.HtmlUnitDriver"))
        {
            return null; // Screenshots not supported in headless mode
        } else {
            return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        }
    }

	

}
