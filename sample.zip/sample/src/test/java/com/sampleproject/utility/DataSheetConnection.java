package com.sampleproject.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataSheetConnection {
	
	private static final String TESTDATA_PATH = System.getProperty("user.dir")+ "src\\\\main\\\\java\\\\com\\\\Inputfiles\\TestDatasheet.xlsx";

	public static final Object[][] readExcel(String sheetName) {

		Workbook workbook = null;

		try {

			workbook = WorkbookFactory.create(new File(TESTDATA_PATH));

		} catch (Exception e) {
			e.printStackTrace();
		}

		Sheet sheet = workbook.getSheet(sheetName);

		Object[][] data = new Object[sheet.getLastRowNum()][sheet
				.getRow(0).getLastCellNum()];

		for (int i = 0; i < sheet.getLastRowNum(); i++) {
			for (int k = 0; k < sheet.getRow(0)
					.getLastCellNum(); k++) {
				data[i][k] = sheet.getRow(i + 1).getCell(k) + "";
			}
		}
		return data;
	}
	
	public static String read(int r , int c) throws Exception
	{
		File src = new File(System.getProperty("user.dir")+  File.separator +"src\\main\\java\\com\\InputFiles\\TestDatasheet.xlsx");
		FileInputStream fis = new FileInputStream(src);
		XSSFWorkbook wb = new XSSFWorkbook(fis); 
		XSSFSheet sh1 = wb.getSheetAt(0);
		
		String s = sh1.getRow(r).getCell(c).getStringCellValue();
		
		return s;
		
	}
	
}
