package com.sampleproject.utility;
import java.util.Properties;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.Scenario;

public class PageWebelements
{


	public PageWebelements()
	{
	}
	protected static WebDriver driver;
	static Properties properties = new Properties();
	protected static Scenario currentScenario; 
     

	/***
	 *
	 * @param id
	 * @return
	 */
	public static boolean IsWebElementDisplayedByID(String id)
	{
		if(driver.findElement(By.id(id)).isDisplayed())
		{
			Assert.assertTrue(true);
			return true;
		}else
		{
			Assert.fail("unable to Identify Webelement by Id");
			return false;
		}
	}
	/***
	 *
	 * @param id
	 * @return
	 */
	public static boolean IsWebElementDisplayedByXpath(String xpath)
	{
		if(driver.findElement(By.xpath(xpath)).isDisplayed())
		{
			Assert.assertTrue(true);
			return true;
		}else
		{
			Assert.fail("unable to Identify Webelement by xpath");
			return false;
		}
	}
	/***
	 *
	 * @param id
	 * @return
	 */
	public static boolean IsWebElementDisplayedByCSS(String css)
	{
		if(driver.findElement(By.cssSelector(css)).isDisplayed())
		{
			Assert.assertTrue(true);
			return true;
		}else
		{
			Assert.fail("unable to Identify Webelement by css");
			return false;
		}
	}
	/***
	 *
	 * @param id
	 * @return
	 */
	public static boolean IsWebElementDisplayedByName(String name)
	{
		if(driver.findElement(By.name(name)).isDisplayed())
		{
			Assert.assertTrue(true);
			return true;
		}else
		{
			Assert.fail("unable to Identify Webelement by name");
			return false;
		}
	}
	/**
	 * @return *
	 *
	 */
	public static boolean switchIframeByIndex(int index)
	{
		if(driver.findElement(By.tagName("Iframe")).isDisplayed())
		{
			driver.switchTo().frame(index);
			Assert.assertTrue(true);
			return true;
		}
		else
		{
			return false;
		}
	}
	/***
	 *
	 * @param css
	 */
	public static void clickCSSWebelement(String css)
	{
		try
		{
			driver.findElement(By.cssSelector(css)).click();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	/***
	 *
	 * @param css
	 */
	public static void sentTextByCSSWebelement(String css,String text)
	{
		try
		{
			driver.findElement(By.cssSelector(css)).sendKeys(text);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/***
	 *
	 * @param css
	 */
	public static void clearTextByCSSWebelement(String css)
	{
		try
		{
			driver.findElement(By.cssSelector(css)).clear();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/***
	 *
	 * @param id
	 */
	public static void clickID(String id)
	{
		try
		{
			driver.findElement(By.id(id)).click();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/***
	 *
	 * @param id
	 */
	public static void sentTextByID(String id,String text)
	{
		try
		{
			driver.findElement(By.id(id)).sendKeys(text);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/***
	 *
	 * @param id
	 */
	public static void clearTextByID(String id)
	{
		try
		{
			driver.findElement(By.id(id)).clear();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/***
	 *
	 * @param xpath
	 */
	public static void clickXpath(String xpath)
	{
		try
		{
			driver.findElement(By.xpath(xpath)).click();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/***
	 *
	 * @param xpath
	 */
	public static void sentTextByXpath(String xpath,String text)
	{
		try
		{
			driver.findElement(By.xpath(xpath)).sendKeys(text);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/***
	 *
	 * @param xpath
	 */
	public static void clearTextByXpath(String xpath)
	{
		try
		{
			driver.findElement(By.xpath(xpath)).clear();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/***
	 *
	 * @param name
	 */
	public static void clickName(String name)
	{
		try
		{
			driver.findElement(By.name(name)).click();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/***
	 *
	 * @param name
	 */
	public static void sentTextByName(String name,String text)
	{
		try
		{
			driver.findElement(By.name(name)).sendKeys(text);
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	/***
	 *
	 * @param name
	 */
	public static void clearTextByName(String name)
	{
		try
		{
			driver.findElement(By.name(name)).clear();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
}