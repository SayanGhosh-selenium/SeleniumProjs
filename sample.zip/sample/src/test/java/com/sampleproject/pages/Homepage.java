package com.sampleproject.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.sampleproject.pageobjects.HomePageWebelements;
import com.sampleproject.pageobjects.PrintTicketWebelements;
import com.sampleproject.utility.DataSheetConnection;
import com.sampleproject.utility.PageWebelements;
import com.sampleproject.utility.Screenshot;
import com.vimalselvam.cucumber.listener.Reporter;

public class Homepage extends PageWebelements{
	
	static WebDriver driver;

	
	public static void SourceLocation()
	{
		try
		{
			if(IsWebElementDisplayedByID(HomePageWebelements.source))
			{
				clickID(HomePageWebelements.source);
				String s = DataSheetConnection.read(1, 3);
				sentTextByID(HomePageWebelements.source,s);
				Thread.sleep(2000);
				driver.findElement(By.id(HomePageWebelements.source)).sendKeys(Keys.ENTER);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	

	public static void DestLocation()
	{
		try
		{
			if(IsWebElementDisplayedByID(HomePageWebelements.destination))
			{
				clickID(HomePageWebelements.destination);
				String s = DataSheetConnection.read(1, 4);
				sentTextByID(HomePageWebelements.destination,s);
				Thread.sleep(2000);
				driver.findElement(By.id(HomePageWebelements.destination)).sendKeys(Keys.ENTER);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void DateSelection()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(HomePageWebelements.date))
			{
				clickXpath(HomePageWebelements.date);
				String expDate = "24";
				WebElement datePicker = driver.findElement(By.xpath(".//*[@id='rb-calendar_onward_cal']"));
				List<WebElement> dates = datePicker.findElements(By.tagName("td"));
				for(WebElement temp:dates){
					if(temp.getText().equals(expDate)){
						temp.click();
						break;
					}
				}
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	

		 

		    
                
            
	
	public static void seachBusesClick()
	{
		try
		{
			if(IsWebElementDisplayedByID(HomePageWebelements.search_buttn))
			{
				clickID(HomePageWebelements.search_buttn);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void rpoolClick()
	{
		try
		{
			if(IsWebElementDisplayedByID(HomePageWebelements.rpool))
			{
				clickID(HomePageWebelements.rpool);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void rbushireClick()
	{
		try
		{
			if(IsWebElementDisplayedByID(HomePageWebelements.rbus_hire))
			{
				clickID(HomePageWebelements.rbus_hire);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void manageMyBooking()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(HomePageWebelements.manage_booking))
			{
				clickXpath(HomePageWebelements.manage_booking);
				Reporter.addScenarioLog("Pass");
				Reporter.addStepLog("Manage my book");
				currentScenario.embed(Screenshot.takeScreenshot(driver), "image/png");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void cancelClick()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(HomePageWebelements.cancel))
			{
				clickXpath(HomePageWebelements.cancel);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void rescheduleClick()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(HomePageWebelements.reschedule))
			{
				clickXpath(HomePageWebelements.reschedule);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void showticketClick()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(HomePageWebelements.print))
			{
				clickXpath(HomePageWebelements.print);
				Reporter.addScenarioLog("Pass");
				Reporter.addStepLog("Print ticket click");
				currentScenario.embed(Screenshot.takeScreenshot(driver), "image/png");
				
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void EmailClick()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(HomePageWebelements.ticket_verf))
			{
				clickXpath(HomePageWebelements.ticket_verf);
				Reporter.addScenarioLog("Pass");
				Reporter.addStepLog("EmailBus click");
				currentScenario.embed(Screenshot.takeScreenshot(driver), "image/png");				
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
