package com.sampleproject.pages;

import org.testng.Assert;

import com.sampleproject.pageobjects.TicketRescheduleWebelements;
import com.sampleproject.utility.DataSheetConnection;
import com.sampleproject.utility.PageWebelements;
import com.vimalselvam.cucumber.listener.Reporter;

public class TicketReschedulingpage extends PageWebelements {
	
	public static void ticketno()
	{
		try
		{
			if(IsWebElementDisplayedByID(TicketRescheduleWebelements.ticketno))
			{
				clickID(TicketRescheduleWebelements.ticketno);
				String s = DataSheetConnection.read(1, 0);
				sentTextByID(TicketRescheduleWebelements.ticketno,s);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public static void email()
	{
		try
		{
			if(IsWebElementDisplayedByID(TicketRescheduleWebelements.emailid))
			{
				clickID(TicketRescheduleWebelements.emailid);
				String s = DataSheetConnection.read(1, 1);
				sentTextByID(TicketRescheduleWebelements.emailid,s);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void clickSubmit()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(TicketRescheduleWebelements.submitbuttn))
			{
				clickXpath(TicketRescheduleWebelements.submitbuttn);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
