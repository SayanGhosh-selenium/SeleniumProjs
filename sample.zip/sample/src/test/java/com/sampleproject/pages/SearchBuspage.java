package com.sampleproject.pages;

import org.testng.Assert;

import com.sampleproject.pageobjects.BusSearchWebelements;
import com.sampleproject.utility.PageWebelements;
import com.vimalselvam.cucumber.listener.Reporter;

public class SearchBuspage extends PageWebelements {
	
	public static void viewbusClick()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(BusSearchWebelements.viewbus))
			{
				clickXpath(BusSearchWebelements.viewbus);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public static void viewseatClick()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(BusSearchWebelements.viewseat))
			{
				clickXpath(BusSearchWebelements.viewseat);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void SeatSelection()
	{
		try
		{
			if(IsWebElementDisplayedByCSS(BusSearchWebelements.seatbook))
			{
				clickCSSWebelement(BusSearchWebelements.seatbook);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void boardingLocationSelection()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(BusSearchWebelements.Boardingpoint))
			{
				clickXpath(BusSearchWebelements.Boardingpoint);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void sourceLocationSelection()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(BusSearchWebelements.droppingpoint))
			{
				clickXpath(BusSearchWebelements.droppingpoint);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void continuebuttnClick()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(BusSearchWebelements.continuebuttn))
			{
				clickXpath(BusSearchWebelements.continuebuttn);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public static void proceedbuttnClick()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(BusSearchWebelements.proceedbuttn))
			{
				clickXpath(BusSearchWebelements.proceedbuttn);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	

}
