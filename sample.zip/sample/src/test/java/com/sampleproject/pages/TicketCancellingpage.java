package com.sampleproject.pages;

import org.testng.Assert;

import com.sampleproject.pageobjects.PrintTicketWebelements;
import com.sampleproject.pageobjects.TicketcancelWebelements;
import com.sampleproject.utility.DataSheetConnection;
import com.sampleproject.utility.PageWebelements;
import com.vimalselvam.cucumber.listener.Reporter;

public class TicketCancellingpage extends PageWebelements {
	
	public static void ticketno()
	{
		try
		{
			if(IsWebElementDisplayedByName(TicketcancelWebelements.ticketno))
			{
				clickID(TicketcancelWebelements.ticketno);
				String s = DataSheetConnection.read(1, 0);
				sentTextByID(TicketcancelWebelements.ticketno,s);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void email()
	{
		try
		{
			if(IsWebElementDisplayedByName(TicketcancelWebelements.emailid))
			{
				clickID(TicketcancelWebelements.emailid);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void clickSubmit()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(TicketcancelWebelements.submitbuttn))
			{
				clickXpath(TicketcancelWebelements.submitbuttn);
				String s = DataSheetConnection.read(1, 1);
				sentTextByXpath(TicketcancelWebelements.submitbuttn,s);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
