package com.sampleproject.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;

import com.sampleproject.pageobjects.HomePageWebelements;
import com.sampleproject.pageobjects.PilligrimageWebelements;
import com.sampleproject.utility.PageWebelements;
import com.vimalselvam.cucumber.listener.Reporter;

public class Pilligrimagepage extends PageWebelements {
	
	public static void pilligrimage()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(PilligrimageWebelements.page))
			{
				clickXpath(PilligrimageWebelements.page);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("window.scrollBy(0,1200)");
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void tirupathi()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(PilligrimageWebelements.tirupathi))
			{
				clickXpath(PilligrimageWebelements.tirupathi);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
