package com.sampleproject.pages;

import org.testng.Assert;

import com.sampleproject.pageobjects.PaymentWebelements;
import com.sampleproject.utility.PageWebelements;
import com.vimalselvam.cucumber.listener.Reporter;

public class Paymentpage extends PageWebelements{
	
	public static void CustName()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(PaymentWebelements.name))
			{
				clickXpath(PaymentWebelements.name);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void CustGender()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(PaymentWebelements.genderM))
			{
				clickXpath(PaymentWebelements.genderM);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void CustAge()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(PaymentWebelements.age))
			{
				clickXpath(PaymentWebelements.age);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void CustEmail()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(PaymentWebelements.email))
			{
				clickXpath(PaymentWebelements.email);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void CustPhn()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(PaymentWebelements.phn))
			{
				clickXpath(PaymentWebelements.phn);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void ProceedButtn()
	{
		try
		{
			if(IsWebElementDisplayedByXpath(PaymentWebelements.submitbuttn))
			{
				clickXpath(PaymentWebelements.submitbuttn);
				Reporter.addScenarioLog("Pass");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
