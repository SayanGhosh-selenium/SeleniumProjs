package com.sampleproject.pages;

import org.testng.Assert;

import com.sampleproject.pageobjects.SendSMSWebelements;
import com.sampleproject.utility.DataSheetConnection;
import com.sampleproject.utility.PageWebelements;
import com.sampleproject.utility.Screenshot;
import com.vimalselvam.cucumber.listener.Reporter;

public class SendSMSpage extends PageWebelements{
	
	public static void ticketno()
	{
		try
		{
			if(IsWebElementDisplayedByID(SendSMSWebelements.ticketno))
			{
				clickID(SendSMSWebelements.ticketno);
				String s = DataSheetConnection.read(1, 0);
				sentTextByID(SendSMSWebelements.ticketno,s);
				Reporter.addScenarioLog("Pass");
				Reporter.addStepLog("ticket number added");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void email()
	{
		try
		{
			if(IsWebElementDisplayedByID(SendSMSWebelements.emailid))
			{
				clickID(SendSMSWebelements.emailid);
				String s = DataSheetConnection.read(1, 1);
				sentTextByID(SendSMSWebelements.emailid,s);
				Reporter.addScenarioLog("Pass");
				Reporter.addStepLog("email added");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void clickSubmit()
	{
		try
		{
			if(IsWebElementDisplayedByID(SendSMSWebelements.submitbuttn))
			{
				clickID(SendSMSWebelements.submitbuttn);
				Reporter.addScenarioLog("Pass");
				Reporter.addStepLog("Error message shown");
				currentScenario.embed(Screenshot.takeScreenshot(driver), "image/png");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
