package com.sampleproject.pages;

import org.testng.Assert;

import com.sampleproject.pageobjects.PrintTicketWebelements;
import com.sampleproject.pageobjects.SendSMSWebelements;
import com.sampleproject.utility.DataSheetConnection;
import com.sampleproject.utility.PageWebelements;
import com.sampleproject.utility.Screenshot;
import com.vimalselvam.cucumber.listener.Reporter;

public class PrintTicketpage extends PageWebelements {
	
	public static void enterTicketno()
	{
		try
		{
			if(IsWebElementDisplayedByID(PrintTicketWebelements.ticketno))
			{
				clickID(PrintTicketWebelements.ticketno);
				String s = DataSheetConnection.read(1, 0);
				sentTextByID(PrintTicketWebelements.ticketno,s);
				Reporter.addScenarioLog("Pass");
				Reporter.addStepLog("ticket number added");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void email()
	{
		try
		{
			if(IsWebElementDisplayedByID(PrintTicketWebelements.emailid))
			{
				clickID(PrintTicketWebelements.emailid);
				String s = DataSheetConnection.read(1, 1);
				sentTextByID(PrintTicketWebelements.emailid,s);
				Reporter.addScenarioLog("Pass");
				Reporter.addStepLog("email added");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void clickSubmit()
	{

		try
		{
			if(IsWebElementDisplayedByID(PrintTicketWebelements.submitbuttn))
			{
				clickID(PrintTicketWebelements.submitbuttn);
				Reporter.addScenarioLog("Pass");
				Reporter.addStepLog("Error message shown");
				currentScenario.embed(Screenshot.takeScreenshot(driver), "image/png");
			}
			else {
				Assert.fail();
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
