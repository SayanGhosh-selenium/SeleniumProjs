package TestngTestscripts;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.sampleproject.pages.Homepage;
import com.sampleproject.pages.Paymentpage;
import com.sampleproject.pages.SearchBuspage;
import com.sampleproject.pages.TicketReschedulingpage;
import com.sampleproject.utility.BrowserType;
import com.sampleproject.utility.InvokeApplication;
import com.sampleproject.utility.PageWebelements;

public class TestngTest2 extends PageWebelements{

	public static WebDriver driver;

	@BeforeTest
	public void loadRedBus() throws FileNotFoundException, IOException {

		driver = BrowserType.getWebDriver();
		InvokeApplication.LaunchRADRApplication(driver);
	}

	@Test(priority=1)
	public void LoadSeachBus(){
		Homepage.SourceLocation();
		Homepage.DestLocation();
		Homepage.DateSelection();
		Homepage.seachBusesClick();
	}

	@Test(priority=2)
	public void BusSeatbook(){
		SearchBuspage.viewbusClick();
		SearchBuspage.viewseatClick();
		SearchBuspage.SeatSelection();
		SearchBuspage.sourceLocationSelection();
		SearchBuspage.boardingLocationSelection();
		SearchBuspage.continuebuttnClick();
		SearchBuspage.proceedbuttnClick();
	}

	@Test(priority=3)
	public void paymentDetails(){
		Paymentpage.CustName();
		Paymentpage.CustGender();
		Paymentpage.CustAge();
		Paymentpage.CustEmail();
		Paymentpage.CustPhn();
		Paymentpage.ProceedButtn();
	}

	@AfterTest
	public void closeBrowser(){
		driver.close();
	}

}
