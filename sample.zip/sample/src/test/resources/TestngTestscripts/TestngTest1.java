/*
 * @Ticket Reschedule
 */
package TestngTestscripts;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.sampleproject.pages.Homepage;
import com.sampleproject.pages.TicketReschedulingpage;
import com.sampleproject.utility.BrowserType;
import com.sampleproject.utility.InvokeApplication;

public class TestngTest1 {

	public static WebDriver driver;

	@BeforeTest
	public void loadRedBus() throws FileNotFoundException, IOException {

		driver = BrowserType.getWebDriver();
		InvokeApplication.LaunchRADRApplication(driver);


	}

	@Test(priority=1)
	public void LoadTicketReschedulepage(){
		Homepage.manageMyBooking();
		Homepage.rescheduleClick();

	}

	@Test(priority=2)
	public void TicketReschedule() throws InterruptedException{
		TicketReschedulingpage.ticketno();
		TicketReschedulingpage.email();
		TicketReschedulingpage.clickSubmit();
		Thread.sleep(4000);
	}

	@AfterTest
	public void closeBrowser(){
		driver.close();
	}



}
