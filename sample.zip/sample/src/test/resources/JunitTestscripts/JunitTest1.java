/*
 * @Ticket cancel 
 */
package JunitTestscripts;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import com.sampleproject.pages.Homepage;
import com.sampleproject.pages.TicketCancellingpage;
import com.sampleproject.utility.BrowserType;
import com.sampleproject.utility.InvokeApplication;
import com.sampleproject.utility.PageWebelements;

public class JunitTest1 extends PageWebelements {

	static WebDriver driver;

	@BeforeClass
	public static void loadRedBus() throws FileNotFoundException, IOException {
		driver = BrowserType.getWebDriver();
		InvokeApplication.LaunchRADRApplication(driver);

	}

	@Test
	public void manage() {
		Homepage.manageMyBooking();
		Homepage.cancelClick();

	}

	@Test
	public void cancel() throws InterruptedException {
		TicketCancellingpage.ticketno();
		TicketCancellingpage.email();
		TicketCancellingpage.clickSubmit();
		Thread.sleep(4000);
	}

	@AfterClass
	public static void executedAfterEach() {
		driver.close();
	}

}
