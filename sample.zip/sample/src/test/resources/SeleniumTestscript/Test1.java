/**
 * @author Sayan
 * 
 * This simple automated selenium script on RedBus
 */


package SeleniumTestscript;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test1 {
	
public static void main(String[] args) throws InterruptedException {
		
		//Setting chromeDriver
		System.setProperty("webdriver.chrome.driver","C:\\Users\\848885\\eclipse-workspace\\sample\\Browsers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.redbus.in");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		//Home page
		driver.findElement(By.xpath("//div[contains(text(),'Manage Booking')]")).click();
		driver.findElement(By.xpath("//span[contains(text(),'Reschedule')]")).click();
		
		//reschedule page operations
		driver.findElement(By.xpath("//input[@id='searchTicket']")).click();
		driver.findElement(By.xpath("//input[@id='searchTicket']")).sendKeys("A4009263");
		driver.findElement(By.xpath("//input[@id='searchEmail']")).click();
		driver.findElement(By.xpath("//input[@id='searchEmail']")).sendKeys("abcd@gmail.com");
		driver.findElement(By.xpath("//input[@id='ticketSearch']")).click();
		
		Thread.sleep(4000);
		driver.close();
		driver.quit();
	}

}
